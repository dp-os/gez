import.meta.chunkName=import.meta.chunkName??"ssr-html@src/views/not-found.ts";export const ids=["830"];export const modules={545:function(t,e,r){r.d(e,{b:()=>n});function n(t){return`
<div>
    <h1>Gez</h1>
    <nav>
        <a href="{{__HTML_BASE__}}/">首页</a>
        <a href="{{__HTML_BASE__}}/about">关于我们</a>
    </nav>
    <main>
    ${t}
    </main>
</div>
`}},286:function(t,e,r){r.d(e,{T:function(){return n}});class n{importMetaSet=new Set;_props=null;get props(){if(null===this._props)throw Error("props is null");return this._props}set props(t){this._props=t}title="";state={};render(){return""}onCreated(){}onClient(){}async onServer(){this.importMetaSet.add(import.meta)}}},654:function(t,e,r){r.r(e),r.d(e,{default:function(){return i}});var n=r(545),o=r(286),s=r(360);class i extends o.T{title=s.title.notFound;render(){return(0,n.b)("<h2>Not Found</h2>")}async onServer(){this.importMetaSet.add(import.meta),super.onServer()}}}};