import.meta.chunkName=import.meta.chunkName??"ssr-html@src/views/about.ts";export const ids=["473"];export const modules={545:function(t,e,r){r.d(e,{b:()=>n});function n(t){return`
<div>
    <h1>Gez</h1>
    <nav>
        <a href="{{__HTML_BASE__}}/">首页</a>
        <a href="{{__HTML_BASE__}}/about">关于我们</a>
    </nav>
    <main>
    ${t}
    </main>
</div>
`}},286:function(t,e,r){r.d(e,{T:function(){return n}});class n{importMetaSet=new Set;_props=null;get props(){if(null===this._props)throw Error("props is null");return this._props}set props(t){this._props=t}title="";state={};render(){return""}onCreated(){}onClient(){}async onServer(){this.importMetaSet.add(import.meta)}}},896:function(t,e,r){r.r(e),r.d(e,{default:function(){return s}});var n=r(545),o=r(286),i=r(360);class s extends o.T{state={time:""};title=i.title.about;render(){return(0,n.b)(`Gez 是一个基于 Rspack 构建的模块链接（Module Link） 解决方案，通过 importmap 将多服务的模块映射到具有强缓存，基于内容哈希的 URL 中。`)}async onServer(){this.importMetaSet.add(import.meta),super.onServer(),this.state.time=new Date().toISOString()}}}};