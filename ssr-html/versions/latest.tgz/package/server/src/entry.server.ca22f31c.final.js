import.meta.chunkName=import.meta.chunkName??"ssr-html@src/entry.server.ts";import*as e from"ssr-html/src/title/index";var t,r,n={360:function(t){t.exports=e}},a={};function o(e){var t=a[e];if(void 0!==t)return t.exports;var r=a[e]={exports:{}};return n[e](r,r.exports,o),r.exports}async function i(e){let t=[{path:"/",page:()=>o.e("193").then(o.bind(o,421)).then(e=>e.default)},{path:"/about",page:()=>o.e("473").then(o.bind(o,896)).then(e=>e.default)}].find(t=>t.path===e);return t?t.page():o.e("830").then(o.bind(o,654)).then(e=>e.default)}o.m=n,o.d=function(e,t){for(var r in t)o.o(t,r)&&!o.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},o.f={},o.e=function(e){return Promise.all(Object.keys(o.f).reduce(function(t,r){return o.f[r](e,t),t},[]))},o.k=function(e){return""+e+".css"},o.u=function(e){return"chunks/"+e+"."+({193:"ac0d4987",473:"d5c4c4fa",830:"93e34b34"})[e]+".final.js"},o.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},o.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},o.p="[[[___GEZ_DYNAMIC_BASE___]]]/ssr-html/",t={289:0},r=function(e){var r=e.ids,n=e.modules,a=e.runtime,i,l,s=0;for(i in n)o.o(n,i)&&(o.m[i]=n[i]);for(a&&a(o);s<r.length;s++)l=r[s],o.o(t,l)&&t[l]&&t[l][0](),t[r[s]]=0},o.f.j=function(e,n){var a=o.o(t,e)?t[e]:void 0;if(0!==a){if(a)n.push(a[1]);else{var i=import("../"+o.u(e)).then(r,function(r){throw 0!==t[e]&&(t[e]=void 0),r}),i=Promise.race([i,new Promise(function(r){a=t[e]=[r]})]);n.push(a[1]=i)}}};let l=async e=>{let t=new(await i(new URL(e.params.url,"file:").pathname));t.importMetaSet=e.importMetaSet,t.props={url:e.params.url},t.onCreated(),await t.onServer();let r=t.render().replaceAll("{{__HTML_BASE__}}",e.params.htmlBase??"");await e.commit(),e.html=`
<!DOCTYPE html>
<html>
<head>
    ${e.preload()}
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${t.title}</title>
    ${e.css()}
</head>
<body>
    <div id="app">
        ${r}
    </div>
    ${e.state("__INIT_PROPS__",t.props)}
    ${e.state("__INIT_STATE__",t.state)}
    ${e.importmap()}
    ${e.moduleEntry()}
    ${e.modulePreload()}
</body>
</html>
`};export{l as default};