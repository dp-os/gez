import.meta.chunkName=import.meta.chunkName??"ssr-html@src/entry.server.ts";import*as e from"ssr-html/src/title";var t,r,n={944:function(t){t.exports=e}},o={};function a(e){var t=o[e];if(void 0!==t)return t.exports;var r=o[e]={exports:{}};return n[e](r,r.exports,a),r.exports}async function i(e){let t=[{path:"/",page:()=>a.e("193").then(a.bind(a,421)).then(e=>e.default)},{path:"/about",page:()=>a.e("473").then(a.bind(a,896)).then(e=>e.default)}].find(t=>t.path===e);return t?t.page():a.e("830").then(a.bind(a,654)).then(e=>e.default)}a.m=n,a.d=function(e,t){for(var r in t)a.o(t,r)&&!a.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},a.f={},a.e=function(e){return Promise.all(Object.keys(a.f).reduce(function(t,r){return a.f[r](e,t),t},[]))},a.k=function(e){return""+e+".css"},a.u=function(e){return"chunks/"+e+"."+({193:"0d54c628",473:"622abe87",830:"e24ae4c5"})[e]+".final.js"},a.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},a.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},a.p="[[[___GEZ_DYNAMIC_BASE___]]]/ssr-html/",t={289:0},r=function(e){var r=e.ids,n=e.modules,o=e.runtime,i,l,s=0;for(i in n)a.o(n,i)&&(a.m[i]=n[i]);for(o&&o(a);s<r.length;s++)l=r[s],a.o(t,l)&&t[l]&&t[l][0](),t[r[s]]=0},a.f.j=function(e,n){var o=a.o(t,e)?t[e]:void 0;if(0!==o){if(o)n.push(o[1]);else{var i=import("../"+a.u(e)).then(r,function(r){throw 0!==t[e]&&(t[e]=void 0),r}),i=Promise.race([i,new Promise(function(r){o=t[e]=[r]})]);n.push(o[1]=i)}}};let l=async e=>{let t=new(await i(new URL(e.params.url,"file:").pathname));t.importMetaSet=e.importMetaSet,t.props={url:e.params.url},t.onCreated(),await t.onServer();let r=t.render().replaceAll("{{__HTML_BASE__}}",e.params.htmlBase??"");await e.commit(),e.html=`
<!DOCTYPE html>
<html>
<head>
    ${e.preload()}
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${t.title}</title>
    ${e.css()}
</head>
<body>
    <div id="app">
        ${r}
    </div>
    ${e.state("__INIT_PROPS__",t.props)}
    ${e.state("__INIT_STATE__",t.state)}
    ${e.importmap()}
    ${e.moduleEntry()}
    ${e.modulePreload()}
</body>
</html>
`};export{l as default};