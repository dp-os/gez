import.meta.chunkName=import.meta.chunkName??"ssr-html@src/entry.server.ts";var t,e,n,r,o,i,a={890:function(t){t.exports=import("ssr-html/src/title/index")}},u={};function c(t){var e=u[t];if(void 0!==e)return e.exports;var n=u[t]={exports:{}};return a[t](n,n.exports,c),n.exports}async function f(t){let e=[{path:"/",page:()=>c.e("982").then(c.bind(c,780)).then(t=>t.default)},{path:"/about",page:()=>c.e("473").then(c.bind(c,896)).then(t=>t.default)}].find(e=>e.path===t);return e?e.page():c.e("830").then(c.bind(c,654)).then(t=>t.default)}c.m=a,t="function"==typeof Symbol?Symbol("webpack queues"):"__webpack_queues__",e="function"==typeof Symbol?Symbol("webpack exports"):"__webpack_exports__",n="function"==typeof Symbol?Symbol("webpack error"):"__webpack_error__",r=function(t){t&&t.d<1&&(t.d=1,t.forEach(function(t){t.r--}),t.forEach(function(t){t.r--?t.r++:t()}))},c.a=function(o,i,a){a&&((u=[]).d=-1);var u,c,f,p,l=new Set,s=o.exports,m=new Promise(function(t,e){p=e,f=t});m[e]=s,m[t]=function(t){u&&t(u),l.forEach(t),m.catch(function(){})},o.exports=m,i(function(o){c=o.map(function(o){if(null!==o&&"object"==typeof o){if(o[t])return o;if(o.then){var i=[];i.d=0,o.then(function(t){a[e]=t,r(i)},function(t){a[n]=t,r(i)});var a={};return a[t]=function(t){t(i)},a}}var u={};return u[t]=function(){},u[e]=o,u});var i,a=function(){return c.map(function(t){if(t[n])throw t[n];return t[e]})},f=new Promise(function(e){(i=function(){e(a)}).r=0;var n=function(t){t===u||l.has(t)||(l.add(t),t&&!t.d&&(i.r++,t.push(i)))};c.map(function(e){e[t](n)})});return i.r?f:a()},function(t){t?p(m[n]=t):f(s),r(u)}),u&&u.d<0&&(u.d=0)},c.d=function(t,e){for(var n in e)c.o(e,n)&&!c.o(t,n)&&Object.defineProperty(t,n,{enumerable:!0,get:e[n]})},c.f={},c.e=function(t){return Promise.all(Object.keys(c.f).reduce(function(e,n){return c.f[n](t,e),e},[]))},c.k=function(t){return""+t+".css"},c.u=function(t){return"chunks/"+t+"."+({473:"ab986625",830:"c9467da2",982:"4c99be7b"})[t]+".final.js"},c.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},c.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},c.p="[[[___GEZ_DYNAMIC_BASE___]]]/ssr-html/",o={289:0},i=function(t){var e=t.ids,n=t.modules,r=t.runtime,i,a,u=0;for(i in n)c.o(n,i)&&(c.m[i]=n[i]);for(r&&r(c);u<e.length;u++)a=e[u],c.o(o,a)&&o[a]&&o[a][0](),o[e[u]]=0},c.f.j=function(t,e){var n=c.o(o,t)?o[t]:void 0;if(0!==n){if(n)e.push(n[1]);else{var r=import("../"+c.u(t)).then(i,function(e){throw 0!==o[t]&&(o[t]=void 0),e}),r=Promise.race([r,new Promise(function(e){n=o[t]=[e]})]);e.push(n[1]=r)}}};let p=async t=>{let e=new(await f(new URL(t.params.url,"file:").pathname));e.importMetaSet=t.importMetaSet,e.props={url:t.params.url},e.onCreated(),await e.onServer();let n=e.render().replaceAll("{{__HTML_BASE__}}",t.params.htmlBase??"");await t.commit(),t.html=`
<!DOCTYPE html>
<html>
<head>
    ${t.preload()}
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${e.title}</title>
    ${t.css()}
</head>
<body>
    <div id="app">
        ${n}
    </div>
    ${t.state("__INIT_PROPS__",e.props)}
    ${t.state("__INIT_STATE__",e.state)}
    ${t.importmap()}
    ${t.moduleEntry()}
    ${t.modulePreload()}
</body>
</html>
`};export{p as default};