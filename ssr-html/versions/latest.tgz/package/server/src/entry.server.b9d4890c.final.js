import.meta.chunkName = import.meta.chunkName ?? "ssr-html@src/entry.server.ts";import * as __WEBPACK_EXTERNAL_MODULE_ssr_html_src_title_index_b0dadcd5__ from "ssr-html/src/title/index";
var __webpack_modules__ = ({
360: (function (module) {

module.exports = __WEBPACK_EXTERNAL_MODULE_ssr_html_src_title_index_b0dadcd5__;


}),

});
/************************************************************************/
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// expose the modules object (__webpack_modules__)
__webpack_require__.m = __webpack_modules__;

/************************************************************************/
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = function(exports, definition) {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/ensure_chunk
(() => {
__webpack_require__.f = {};
// This file contains only the entry chunk.
// The chunk loading function for additional chunks
__webpack_require__.e = function (chunkId) {
	return Promise.all(
		Object.keys(__webpack_require__.f).reduce(function (promises, key) {
			__webpack_require__.f[key](chunkId, promises);
			return promises;
		}, [])
	);
};

})();
// webpack/runtime/get css chunk filename
(() => {
// This function allow to reference chunks
        __webpack_require__.k = function (chunkId) {
          // return url for filenames not based on template
          
          // return url for filenames based on template
          return "" + chunkId + ".css";
        };
      
})();
// webpack/runtime/get javascript chunk filename
(() => {
// This function allow to reference chunks
        __webpack_require__.u = function (chunkId) {
          // return url for filenames not based on template
          
          // return url for filenames based on template
          return "chunks/" + chunkId + "." + {"459": "d7affc44","473": "de2c0381","830": "0fad5e63",}[chunkId] + ".final.js";
        };
      
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = function (obj, prop) {
	return Object.prototype.hasOwnProperty.call(obj, prop);
};

})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = function(exports) {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};

})();
// webpack/runtime/public_path
(() => {
__webpack_require__.p = "[[[___GEZ_DYNAMIC_BASE___]]]/ssr-html/";

})();
// webpack/runtime/module_chunk_loading
(() => {

      // object to store loaded and loading chunks
      // undefined = chunk not loaded, null = chunk preloaded/prefetched
      // [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
      var installedChunks = {"289": 0,};
      var installChunk = function (data) {
    var ids = data.ids;
    var modules = data.modules;
    var runtime = data.runtime;
    // add "modules" to the modules object,
    // then flag all "ids" as loaded and fire callback
    var moduleId, chunkId, i = 0;
    for (moduleId in modules) {
        if (__webpack_require__.o(modules, moduleId)) {
            __webpack_require__.m[moduleId] = modules[moduleId];
        }
    }
    if (runtime) runtime(__webpack_require__);
    for (; i < ids.length; i++) {
        chunkId = ids[i];
        if (__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
            installedChunks[chunkId][0]();
        }
        installedChunks[ids[i]] = 0;
    }
    
};
        __webpack_require__.f.j = function (chunkId, promises) {
          // import() chunk loading for javascript
var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
if (installedChunkData !== 0) { // 0 means "already installed".'
    // a Promise means "currently loading".
    if (installedChunkData) {
        promises.push(installedChunkData[1]);
    } else {
        if (true) {
            // setup Promise in chunk cache
            var promise = import("../" + __webpack_require__.u(chunkId)).then(installChunk, function (e) {
                if (installedChunks[chunkId] !== 0) installedChunks[chunkId] = undefined;
                throw e;
            });
            var promise = Promise.race([promise, new Promise(function (resolve) {
                installedChunkData = installedChunks[chunkId] = [resolve];
            })]);
            promises.push(installedChunkData[1] = promise);
        }
        
    }
}
        }
        
})();
/************************************************************************/
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/styles/global.css

;// CONCATENATED MODULE: ./src/routes.ts

async function getRoutePage(path) {
    const routes = [
        {
            path: '/',
            page: ()=>__webpack_require__.e(/* import() */ "459").then(__webpack_require__.bind(__webpack_require__, 40)).then((m)=>m.default)
        },
        {
            path: '/about',
            page: ()=>__webpack_require__.e(/* import() */ "473").then(__webpack_require__.bind(__webpack_require__, 896)).then((m)=>m.default)
        }
    ];
    const route = routes.find((item)=>{
        return item.path === path;
    });
    if (route) {
        return route.page();
    }
    return __webpack_require__.e(/* import() */ "830").then(__webpack_require__.bind(__webpack_require__, 654)).then((m)=>m.default);
}

;// CONCATENATED MODULE: ./src/entry.server.ts

/* ESM default export */ const entry_server = ((async (rc)=>{
    // 渲染页面内容
    const Page = await getRoutePage(new URL(rc.params.url, 'file:').pathname);
    const page = new Page();
    page.importMetaSet = rc.importMetaSet;
    page.props = {
        url: rc.params.url,
        base: rc.params.base || '/'
    };
    page.onCreated();
    await page.onServer();
    const html = page.render();
    // 提交模块依赖收集
    await rc.commit();
    rc.html = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    ${rc.preload()}
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${page.title}</title>
    <link rel="icon" type="image/svg+xml" href="https://www.gez-esm.com/logo.svg">
    ${rc.css()}
</head>
<body>
    <div id="app">
        ${html}
    </div>
    ${rc.state('__INIT_PROPS__', page.props)}
    ${rc.state('__INIT_STATE__', page.state)}
    ${rc.importmap()}
    ${rc.moduleEntry()}
    ${rc.modulePreload()}
</body>
</html>
`;
}));

export { entry_server as default };
