async function start() {
    const options = await import('./node/src/entry.node.js').then(
        (mod) => mod.default
    );
    const { Gez } = await import('@gez/core');
    const gez = new Gez(options);

    await gez.init(gez.COMMAND.start);
}

start();