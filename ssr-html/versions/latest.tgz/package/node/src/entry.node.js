import { createRequire as __WEBPACK_EXTERNAL_createRequire } from "node:module";
// The require scope
var __webpack_require__ = {};

/************************************************************************/
// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = function (module) {
	var getter = module && module.__esModule ?
		function () { return module['default']; } :
		function () { return module; };
	__webpack_require__.d(getter, { a: getter });
	return getter;
};




})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = function(exports, definition) {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = function (obj, prop) {
	return Object.prototype.hasOwnProperty.call(obj, prop);
};

})();
/************************************************************************/

;// CONCATENATED MODULE: external "node:http"
const external_node_http_namespaceObject = __WEBPACK_EXTERNAL_createRequire(import.meta.url)("node:http");
var external_node_http_default = /*#__PURE__*/__webpack_require__.n(external_node_http_namespaceObject);
;// CONCATENATED MODULE: ./src/entry.node.ts
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _ts_generator(thisArg, body) {
    var f, y, t, g, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    };
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(_)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}

/* ESM default export */ const entry_node = ({
    packs: {
        enable: true
    },
    devApp: // 本地执行 dev 和 build 时会使用
    function(gez) {
        return _async_to_generator(function() {
            return _ts_generator(this, function(_state) {
                // 这里应使用动态模块。生产依赖不存在。
                return [
                    2,
                    import("@gez/rspack").then(function(m) {
                        return m.createRspackHtmlApp(gez, {
                            minimize: false,
                            config: function(context) {
                            // 可以在这里修改 Rspack 编译的配置
                            // 自定义你的 Vue、React等框架的打包逻辑
                            }
                        });
                    })
                ];
            });
        })();
    },
    server: function(gez) {
        return _async_to_generator(function() {
            var server;
            return _ts_generator(this, function(_state) {
                server = external_node_http_default().createServer(function(req, res) {
                    // 静态文件处理
                    gez.middleware(req, res, /*#__PURE__*/ _async_to_generator(function() {
                        var rc;
                        return _ts_generator(this, function(_state) {
                            switch(_state.label){
                                case 0:
                                    res.setHeader('Content-Type', 'text/html;charset=UTF-8');
                                    return [
                                        4,
                                        gez.render({
                                            importmapMode: 'js',
                                            params: {
                                                url: req.url
                                            }
                                        })
                                    ];
                                case 1:
                                    rc = _state.sent();
                                    // 响应 HTML 内容
                                    res.end(rc.html);
                                    return [
                                        2
                                    ];
                            }
                        });
                    }));
                });
                // 监听端口
                server.listen(3000, function() {
                    console.log('http://localhost:3000');
                });
                return [
                    2
                ];
            });
        })();
    },
    postBuild: function(gez) {
        return _async_to_generator(function() {
            var list, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, url, rc, err;
            return _ts_generator(this, function(_state) {
                switch(_state.label){
                    case 0:
                        list = [
                            '/',
                            '/about',
                            '/404'
                        ];
                        _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                        _state.label = 1;
                    case 1:
                        _state.trys.push([
                            1,
                            6,
                            7,
                            8
                        ]);
                        _iterator = list[Symbol.iterator]();
                        _state.label = 2;
                    case 2:
                        if (!!(_iteratorNormalCompletion = (_step = _iterator.next()).done)) return [
                            3,
                            5
                        ];
                        url = _step.value;
                        return [
                            4,
                            gez.render({
                                params: {
                                    url: url,
                                    base: '/ssr-html/'
                                }
                            })
                        ];
                    case 3:
                        rc = _state.sent();
                        gez.writeSync(gez.resolvePath('dist/client', url.substring(1), 'index.html'), rc.html);
                        _state.label = 4;
                    case 4:
                        _iteratorNormalCompletion = true;
                        return [
                            3,
                            2
                        ];
                    case 5:
                        return [
                            3,
                            8
                        ];
                    case 6:
                        err = _state.sent();
                        _didIteratorError = true;
                        _iteratorError = err;
                        return [
                            3,
                            8
                        ];
                    case 7:
                        try {
                            if (!_iteratorNormalCompletion && _iterator["return"] != null) {
                                _iterator["return"]();
                            }
                        } finally{
                            if (_didIteratorError) {
                                throw _iteratorError;
                            }
                        }
                        return [
                            7
                        ];
                    case 8:
                        return [
                            2
                        ];
                }
            });
        })();
    },
    modules: {
        exports: [
            'root:src/title/index.ts'
        ]
    }
});

export { entry_node as default };
