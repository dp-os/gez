import.meta.chunkName=import.meta.chunkName??"ssr-html@src/views/not-found.ts";export const ids=["830"];export const modules={878:function(t,r,e){function n(t){return`
<div>
    <h1>Gez</h1>
    <nav>
        <a href="{{__HTML_BASE__}}/">首页</a>
        <a href="{{__HTML_BASE__}}/about">关于我们</a>
    </nav>
    <main>
    ${t}
    </main>
</div>
`}e.d(r,{b:function(){return n}}),e(992)},286:function(t,r,e){e.d(r,{T:function(){return n}});class n{importMetaSet=new Set;_props=null;get props(){if(null===this._props)throw Error("props is null");return this._props}set props(t){this._props=t}title="";state={};render(){return""}onCreated(){}onClient(){}async onServer(){this.importMetaSet.add(import.meta)}}},654:function(t,r,e){e.r(r),e.d(r,{default:function(){return i}});var n=e(878),o=e(286),s=e(944);class i extends o.T{title=s.title.notFound;render(){return(0,n.b)("<h2>Not Found</h2>")}async onServer(){this.importMetaSet.add(import.meta),super.onServer()}}},992:function(t,r,e){t.exports={}}};