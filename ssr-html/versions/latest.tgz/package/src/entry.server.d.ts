import type { RenderContext } from '@gez/core';
declare const _default: (rc: RenderContext) => Promise<void>;
export default _default;
