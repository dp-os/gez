import { Page } from '../page';
export default class NotFound extends Page {
    title: string;
    render(): string;
    onServer(): Promise<void>;
}
