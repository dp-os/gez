import { Page } from 'ssr-html/src/page';
export default class Home extends Page {
    state: {
        count: number;
    };
    title: string;
    render(): string;
    onClient(): void;
    /**
     * 模拟服务端请求数据
     */
    onServer(): Promise<void>;
}
