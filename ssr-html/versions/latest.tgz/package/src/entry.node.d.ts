declare const _default: {
    packs: {
        enable: true;
    };
    devApp(gez: import("@gez/core").Gez): Promise<import("@gez/core").App>;
    server(gez: import("@gez/core").Gez): Promise<void>;
    postBuild(gez: import("@gez/core").Gez): Promise<void>;
    modules: {
        exports: string[];
    };
};
export default _default;
