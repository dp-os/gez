declare const _default: {
    packs: {
        enable: true;
    };
    createDevApp(gez: import("@gez/core").Gez): Promise<import("@gez/core").App>;
    createServer(gez: import("@gez/core").Gez): Promise<void>;
    postCompileProdHook(gez: import("@gez/core").Gez): Promise<void>;
    modules: {
        exports: string[];
    };
};
export default _default;
