import './layout.css';
export declare function layout(slot: string): string;
