export interface PageProps {
    url: string;
    base: string;
}
export declare class Page {
    importMetaSet: Set<ImportMeta>;
    private _props;
    get props(): PageProps;
    set props(props: PageProps);
    title: string;
    /**
     * 自定义页面状态
     */
    state: Record<string, any>;
    /**
     * 服务端渲染生成的 HTML
     */
    render(): string;
    /**
     * 组件已经创建完成，props 和 state 已经准备就绪
     */
    onCreated(): void;
    /**
     * 客户端执行
     */
    onClient(): void;
    /**
     * 服务端执行
     */
    onServer(): Promise<void>;
}
