declare const _default: {
    packs: {
        enable: true;
    };
    modules: {
        exports: string[];
    };
    createDevApp(gez: import("@gez/core").Gez): Promise<import("@gez/core").App>;
    createServer(gez: import("@gez/core").Gez): Promise<void>;
    postCompileProdHook(gez: import("@gez/core").Gez): Promise<void>;
};
export default _default;
